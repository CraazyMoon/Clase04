/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package curso.tecnicas.teoria;

/**
 *
 * @author Alumno 20
 */
public class Clase27CM {
    public static void main(String[] args) {
        /*
        AWT (abstrct Windows  Toolkit)
        */
    }
    
}
